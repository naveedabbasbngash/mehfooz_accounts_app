import 'dart:io';
import 'package:path/path.dart' as p;


class SqliteImportService {
  /// Copies SQLite file into app storage safely
  /*static Future<String?> importAndSaveDb(String originalPath) async {
    final file = File(originalPath);

    if (!await file.exists()) return null;

    // Accept only .sqlite
    final ext = p.extension(originalPath).toLowerCase();
    if (ext != '.sqlite') return null;

    // Destination folder inside app
    final appDir = await getApplicationDocumentsDirectory();
    final dbDir = Directory(p.join(appDir.path, 'imported_db'));

    if (!await dbDir.exists()) {
      await dbDir.create(recursive: true);
    }

    // Avoid override by timestamp
    final newName = 'db_${DateTime.now().millisecondsSinceEpoch}.sqlite';
    final newPath = p.join(dbDir.path, newName);

    await file.copy(newPath);
    return newPath;
  }

  /// Read table list from imported database
  static Future<List<String>> getTables(String dbPath) async {
    final db = await openDatabase(dbPath);
    final result = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';",
    );

    await db.close();

    return result.map((e) => e['name'] as String).toList();
  }*/
}
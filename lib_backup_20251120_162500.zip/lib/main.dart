import 'package:flutter/material.dart';
import 'package:flutter_slider_drawer/flutter_slider_drawer.dart';
import 'package:provider/provider.dart';

// ✅ Just import this — do NOT instantiate
import 'package:sqlite3_flutter_libs/sqlite3_flutter_libs.dart';

import 'model/user_model.dart';
import 'services/auth_service.dart';
import 'ui/auth/auth_screen.dart';
import 'ui/home/home_wrapper.dart';
import 'viewmodel/home/home_view_model.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ✅ DO NOT instantiate SqliteFlutterLibs — importing is enough for Android/iOS support

  runApp(const MahfoozApp());
}

class MahfoozApp extends StatefulWidget {
  const MahfoozApp({super.key});

  @override
  State<MahfoozApp> createState() => _MahfoozAppState();
}

class _MahfoozAppState extends State<MahfoozApp> {
  UserModel? _user;
  bool _loading = true;

  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();
  final GlobalKey<SliderDrawerState> _sliderDrawerKey = GlobalKey<SliderDrawerState>();

  @override
  void initState() {
    super.initState();
    _loadUser();
  }

  Future<void> _loadUser() async {
    print("🔵 Loading saved user on app start...");

    _user = await AuthService.loadSavedUser();

    setState(() {
      _loading = false;
    });

    if (_user == null) {
      print("⚠ No saved user → showing AuthScreen");
    } else {
      print("✅ Saved user found → auto-login");
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const MaterialApp(
        home: Scaffold(
          body: Center(child: CircularProgressIndicator()),
        ),
      );
    }

    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => HomeViewModel(
            navigatorKey: _navigatorKey,
            sliderDrawerKey: _sliderDrawerKey,
          ),
        ),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        navigatorKey: _navigatorKey,
        home: _user == null
            ? const AuthScreen()
            : HomeWrapper(
          user: _user!,
          sliderDrawerKey: _sliderDrawerKey,
        ),
      ),
    );
  }
}
class PendingAmountRow {
  final String currency;
  final double pending;

  PendingAmountRow({
    required this.currency,
    required this.pending,
  });

  factory PendingAmountRow.fromQuery(Map<String, dynamic> row) {
    return PendingAmountRow(
      currency: row['currencyStatus'] as String,
      pending: (row['pending'] as num).toDouble(),
    );
  }
}
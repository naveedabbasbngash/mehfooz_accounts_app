// Place this file in: lib/ui/profile/profile_screen.dart

import 'package:flutter/material.dart';

import '../../data/profile/profile_repository.dart';
import '../../viewmodel/profile/profile_view_model.dart';
import '../../model/user_model.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text("Reports Screen"));
  }

  Widget _buildProfileUI(UserModel user) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          CircleAvatar(
            radius: 50,
            backgroundImage:
            user.imageUrl.isNotEmpty ? NetworkImage(user.imageUrl) : null,
            child: user.imageUrl.isEmpty
                ? const Icon(Icons.person, size: 50)
                : null,
          ),
          const SizedBox(height: 16),

          Text(
            user.fullName,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          Text(
            user.email,
            style: const TextStyle(fontSize: 16, color: Colors.grey),
          ),

          const SizedBox(height: 20),

          _infoCard(Icons.verified_user, "Login Status",
              user.isLogin == 1 ? "Logged In" : "Logged Out"),

          if (user.planStatus != null)
            _infoCard(Icons.subscriptions, "Plan",
                "${user.planStatus!.statusText} (${user.subscription?.planTitle ?? 'N/A'})"),

          if (user.expiry != null)
            _infoCard(Icons.timer, "Remaining Days",
                "${user.expiry!.remainingDays} days"),

          if (user.subscription != null)
            _infoCard(Icons.calendar_month, "Subscription Period",
                "${user.subscription!.startDate} → ${user.subscription!.endDate}"),
        ],
      ),
    );
  }

  Widget _infoCard(IconData icon, String title, String value) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: ListTile(
        leading: Icon(icon, size: 28),
        title: Text(title,
            style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(value),
      ),
    );
  }
}
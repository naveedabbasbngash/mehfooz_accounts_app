import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../model/home/pending_amount_row.dart';
import '../../viewmodel/home/home_viewmodel.dart';
import '../debug/debug_screen.dart';

class HomeScreenContent extends StatelessWidget {
  final String? verifiedDbPath;

  const HomeScreenContent({
    super.key,
    this.verifiedDbPath,
  });

  @override
  Widget build(BuildContext context) {
    return Consumer<HomeViewModel>(
      builder: (context, viewModel, _) {
        final List<PendingAmountRow> pendingAmounts = viewModel.pendingAmounts;

        return Scaffold(
          appBar: AppBar(
            title: const Text("Home"),
            actions: [
              PopupMenuButton<String>(
                onSelected: (value) {
                  if (value == 'debug') {
                    if (verifiedDbPath == null) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("❌ No verified database found")),
                      );
                    } else {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => DebugDbScreen(dbPath: verifiedDbPath!),
                        ),
                      );
                    }
                  }
                },
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: 'debug',
                    child: Text('🧪 Debug Database'),
                  ),
                ],
              ),
            ],
          ),
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    "Welcome to Mahfooz Accounts",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 20),

                  if (verifiedDbPath != null)
                    Text(
                      "📁 Loaded DB:\n$verifiedDbPath",
                      textAlign: TextAlign.center,
                    )
                  else
                    const Text(
                      "⚠ No DB imported yet",
                      style: TextStyle(color: Colors.grey),
                    ),

                  const SizedBox(height: 20),

                  if (pendingAmounts.isNotEmpty) ...[
                    const Divider(),
                    const Text(
                      "💰 Pending Amounts by Currency",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    ...pendingAmounts.map((e) => Text("• ${e.currencyStatus} → ${e.total.toStringAsFixed(2)}")),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
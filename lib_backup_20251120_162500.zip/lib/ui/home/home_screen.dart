import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

import '../../services/logging/logger_service.dart';
import '../../viewmodel/home/home_view_model.dart';
import '../debug/debug_screen.dart';

class HomeScreenContent extends StatelessWidget {
  const HomeScreenContent({super.key});

  @override
  Widget build(BuildContext context) {
    LoggerService.debug("🏠 HomeScreenContent → build() called");

    final formatter = NumberFormat.decimalPattern(); // ✅ formats: 4070000 → 4,070,000

    return Consumer<HomeViewModel>(
      builder: (context, vm, _) {
        LoggerService.debug("📡 HomeScreenContent → Consumer rebuilt");

        final dbPath = vm.verifiedDbPath;
        final pendingList = vm.pendingAmounts;

        return Scaffold(
          appBar: AppBar(
            title: const Text("Pending Summary"),
            actions: [
              PopupMenuButton<String>(
                onSelected: (value) {
                  if (value == 'debug') {
                    if (dbPath == null) {
                      LoggerService.warn("⚠ Tried to debug DB but no dbPath found.");
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("❌ No verified database found"),
                        ),
                      );
                      return;
                    }

                    LoggerService.info("🚀 Navigating to DebugDbScreen for: $dbPath");
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => DebugDbScreen(dbPath: dbPath),
                      ),
                    );
                  }
                },
                itemBuilder: (context) => const [
                  PopupMenuItem<String>(
                    value: 'debug',
                    child: Text("🧪 Debug Imported Database"),
                  ),
                ],
              )
            ],
          ),
          body: Padding(
            padding: const EdgeInsets.all(16),
            child: pendingList.isEmpty
                ? const Center(
              child: Text(
                "No pending data found.",
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            )
                : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "💰 Pending Amount Summary by Currency",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey.shade800,
                  ),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: ListView.separated(
                    itemCount: pendingList.length,
                    separatorBuilder: (_, __) => const Divider(),
                    itemBuilder: (context, index) {
                      final row = pendingList[index];

                      final notPaid = formatter.format(row.notPaidAmount ~/ 100);
                      final paid = formatter.format(row.paidAmount ~/ 100);
                      final balance = formatter.format(row.balance); // already in rupees

                      return ListTile(
                        contentPadding: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
                        leading: CircleAvatar(
                          backgroundColor: Colors.blue.shade50,
                          child: Text(
                            row.currency.substring(0, 2).toUpperCase(),
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.blue,
                            ),
                          ),
                        ),
                        title: Text(
                          row.currency,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        subtitle: Text("Not Paid: $notPaid | Paid: $paid"),
                        trailing: Text(
                          balance,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: row.balance < 0 ? Colors.red : Colors.green,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}